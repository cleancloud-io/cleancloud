# CleanCloud Docker Provider — Integration Guide

## Step 1: Create New Files

Upload all files from the `cleancloud/providers/docker/` folder in this zip to your fork.

The structure:
```
cleancloud/providers/docker/
├── __init__.py
├── session.py
├── validate.py
├── scan.py
└── rules/
    ├── __init__.py
    ├── container_stopped.py
    ├── container_no_healthcheck.py
    ├── container_restart_loop.py
    ├── image_dangling.py
    ├── volume_unused.py
    └── network_orphaned.py
```

## Step 2: Edit `cleancloud/config/schema.py`

Find this line:
```python
_VALID_PROVIDERS = {"aws", "azure", "gcp"}
```

Replace with:
```python
_VALID_PROVIDERS = {"aws", "azure", "gcp", "docker"}
```

## Step 3: Edit `cleancloud/cli.py`

Find this block:
```python
    try:
        import google.cloud.compute_v1  # noqa: F401

        providers.append("gcp")
    except ImportError:
        pass
```

Add directly after it:
```python
    try:
        import docker as _docker_lib  # noqa: F401

        providers.append("docker")
    except ImportError:
        pass
```

## Step 4: Edit `cleancloud/scan/command.py`

### 4a. Add Docker imports

Find:
```python
from cleancloud.providers.gcp.scan import (
    GCP_AI_RULES,
    GCP_RULE_MAP,
    GCP_RULE_MAP_AI,
    GCP_RULES,
    ProjectScanResult,
    scan_gcp_with_project_selection,
)
```

Add directly after:
```python
from cleancloud.providers.docker.scan import (
    DOCKER_AI_RULES,
    DOCKER_RULE_MAP,
    DOCKER_RULE_MAP_AI,
    DOCKER_RULES,
    scan_docker,
)
```

### 4b. Add "docker" to provider choices

Find:
```python
    type=click.Choice(["aws", "azure", "gcp"]),
```

Replace with:
```python
    type=click.Choice(["aws", "azure", "gcp", "docker"]),
```

### 4c. Add Docker rule building

Find:
```python
    policy_skipped = aws_policy_skipped + azure_policy_skipped + gcp_policy_skipped
```

Add directly before that line:
```python
    # Build the Docker rule list based on --category
    if provider == "docker":
        if category == "hygiene":
            docker_rules_to_run = list(DOCKER_RULES)
        elif category == "ai":
            docker_rules_to_run = list(DOCKER_AI_RULES)
        else:  # all
            docker_rules_to_run = list(DOCKER_RULES) + list(DOCKER_AI_RULES)
        docker_rule_map = {**DOCKER_RULE_MAP, **DOCKER_RULE_MAP_AI}
        try:
            docker_rules_to_run, docker_policy_skipped = apply_rule_config(
                docker_rules_to_run, docker_rule_map, cfg, skip_ids
            )
        except ValueError as e:
            click.echo(f"Error in policy config: {e}", err=True)
            click.echo("See docs/configuration.md for valid options.", err=True)
            sys.exit(EXIT_ERROR)
    else:
        docker_rules_to_run = list(DOCKER_RULES)
        docker_policy_skipped: list = []

```

And change the policy_skipped line to:
```python
    policy_skipped = aws_policy_skipped + azure_policy_skipped + gcp_policy_skipped + docker_policy_skipped
```

### 4d. Add Docker scanning block

Find:
```python
        elif provider == "gcp":
            project_list = list(project) if project else None
            (
                project_selection_mode,
                findings,
                projects_scanned,
                skipped_rules,
                gcp_project_results,
            ) = scan_gcp_with_project_selection(
                region=region,
                projects=project_list,
                all_projects=all_projects,
                concurrency=concurrency,
                rules=gcp_rules_to_run,
            )
            # Extract unique regions/zones from findings
            regions_scanned = sorted(set(f.region for f in findings if f.region))
```

Add directly after:
```python

        elif provider == "docker":
            findings, skipped_rules = scan_docker(
                host=None,  # uses default Docker socket
                rules=docker_rules_to_run,
            )
```

### 4e. Add Docker to rules_evaluated map

Find:
```python
        # Build rules_evaluated: {rule_id: finding_count} for all rules that ran
        if provider == "aws":
            _active_rule_map = {v: k for k, v in aws_rule_map.items() if v in aws_rules_to_run}
        elif provider == "azure":
            _active_rule_map = {v: k for k, v in azure_rule_map.items() if v in azure_rules_to_run}
        else:
            _active_rule_map = {v: k for k, v in gcp_rule_map.items() if v in gcp_rules_to_run}
```

Replace with:
```python
        # Build rules_evaluated: {rule_id: finding_count} for all rules that ran
        if provider == "aws":
            _active_rule_map = {v: k for k, v in aws_rule_map.items() if v in aws_rules_to_run}
        elif provider == "azure":
            _active_rule_map = {v: k for k, v in azure_rule_map.items() if v in azure_rules_to_run}
        elif provider == "docker":
            _active_rule_map = {v: k for k, v in docker_rule_map.items() if v in docker_rules_to_run}
        else:
            _active_rule_map = {v: k for k, v in gcp_rule_map.items() if v in gcp_rules_to_run}
```

### 4f. Fix EnvironmentError handler (also fixes the existing bug)

Find:
```python
    except EnvironmentError as e:
        # Raised by create_azure_session() or create_gcp_session() when auth fails
        click.echo()
        click.echo(f"Authentication failed — {e}")
        click.echo()
        if provider == "gcp":
            click.echo("Run `cleancloud doctor --provider gcp` to diagnose.")
        else:
            click.echo("Run `cleancloud doctor --provider azure` to diagnose.")
        sys.exit(EXIT_PERMISSION_ERROR)
```

Replace with:
```python
    except EnvironmentError as e:
        # Raised by create_azure_session(), create_gcp_session(), or create_docker_session()
        click.echo()
        click.echo(f"Connection failed — {e}")
        click.echo()
        if provider == "gcp":
            click.echo("Run `cleancloud doctor --provider gcp` to diagnose.")
        elif provider == "docker":
            click.echo("Check that Docker is running and the socket is accessible.")
        elif provider == "aws":
            click.echo("Run `cleancloud doctor --provider aws` to diagnose.")
        else:
            click.echo("Run `cleancloud doctor --provider azure` to diagnose.")
        sys.exit(EXIT_PERMISSION_ERROR)
```

## Step 5: Edit `pyproject.toml`

Find:
```toml
dependencies = [
    "click>=8.1.0",
    "PyYAML>=6.0",
```

Add after `"PyYAML>=6.0",`:
```toml
    # Docker
    "docker>=7.0.0",
```

## Done!

After all edits, run:
```bash
cleancloud scan --provider docker
```
